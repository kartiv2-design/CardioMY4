package com.cardiohrv.monitor

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.cardiohrv.monitor.databinding.ActivityMainBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var camera: Camera? = null
    private var measuring = false
    private var measureStartMs = 0L
    private val MEASURE_DURATION_MS = 60_000L
    private val PERM_CODE = 100
    private val processor = SignalProcessor()
    private val handler = Handler(Looper.getMainLooper())

    // Metric card references (label, value, progress, color)
    private data class MetricCard(val label: TextView, val value: TextView, val bar: ProgressBar, val color: Int)
    private lateinit var mRmssd: MetricCard
    private lateinit var mSdnn: MetricCard
    private lateinit var mPnn50: MetricCard
    private lateinit var mStress: MetricCard
    private lateinit var mRr: MetricCard

    private val uiUpdater = object : Runnable {
        override fun run() { if (measuring) { updateUI(); handler.postDelayed(this, 250) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraExecutor = Executors.newSingleThreadExecutor()

        // Wire metric cards
        mRmssd = MetricCard(
            b.cardRmssd.findViewById(R.id.tvMetricLabel),
            b.cardRmssd.findViewById(R.id.tvMetricValue),
            b.cardRmssd.findViewById(R.id.metricProgress),
            0xFF00D4FF.toInt())
        mSdnn  = MetricCard(
            b.cardSdnn.findViewById(R.id.tvMetricLabel),
            b.cardSdnn.findViewById(R.id.tvMetricValue),
            b.cardSdnn.findViewById(R.id.metricProgress),
            0xFF00E87A.toInt())
        mPnn50 = MetricCard(
            b.cardPnn50.findViewById(R.id.tvMetricLabel),
            b.cardPnn50.findViewById(R.id.tvMetricValue),
            b.cardPnn50.findViewById(R.id.metricProgress),
            0xFF00E87A.toInt())
        mStress= MetricCard(
            b.cardStress.findViewById(R.id.tvMetricLabel),
            b.cardStress.findViewById(R.id.tvMetricValue),
            b.cardStress.findViewById(R.id.metricProgress),
            0xFFFFB020.toInt())
        mRr    = MetricCard(
            b.cardRr.findViewById(R.id.tvMetricLabel),
            b.cardRr.findViewById(R.id.tvMetricValue),
            b.cardRr.findViewById(R.id.metricProgress),
            0xFFA8C8E8.toInt())

        mRmssd.label.text = "RMSSD"
        mSdnn.label.text  = "SDNN"
        mPnn50.label.text = "pNN50"
        mStress.label.text= "СТРЕСС"
        mRr.label.text    = "RR"

        listOf(mRmssd, mSdnn, mPnn50, mStress, mRr).forEach {
            it.value.setTextColor(it.color)
            it.bar.progressTintList = android.content.res.ColorStateList.valueOf(it.color)
        }

        b.btnStart.setOnClickListener {
            if (measuring) stopMeasurement() else requestCameraAndStart()
        }
        setStep(1)
    }

    private fun requestCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startMeasurement()
        else
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERM_CODE)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == PERM_CODE && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startMeasurement()
        else Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
    }

    private fun startMeasurement() {
        measuring = true; measureStartMs = System.currentTimeMillis()
        processor.reset()
        processor.onBeat = { handler.post { animateHeart() } }
        b.btnStart.text = "■  Остановить"
        b.btnStart.setBackgroundColor(0xFFCC2244.toInt())
        b.statusDot.setBackgroundResource(R.drawable.dot_green)
        b.statusText.text = "Калибровка..."
        b.viewfinderOverlay.visibility = View.VISIBLE
        setStep(2); startCamera(); handler.post(uiUpdater)
    }

    private fun stopMeasurement() {
        measuring = false; handler.removeCallbacks(uiUpdater)
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
        camera = null
        b.btnStart.text = "▶  Начать измерение"
        b.btnStart.setBackgroundColor(0xFF0D1A10.toInt())
        b.statusDot.setBackgroundResource(R.drawable.dot_idle)
        b.statusText.text = "Ожидание"
        b.viewfinderOverlay.visibility = View.GONE
        b.progressBar.progress = 0
        b.tvProgress.text = "Готов к измерению"
        b.tvBpm.text = "—"; setStep(1)
    }

    private fun startCamera() {
        ProcessCameraProvider.getInstance(this).addListener({
            val prov = ProcessCameraProvider.getInstance(this).get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(b.previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(android.util.Size(320, 240))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { img -> if (measuring) processFrame(img); img.close() }
            try {
                prov.unbindAll()
                camera = prov.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                camera?.cameraControl?.enableTorch(true)
            } catch (e: Exception) { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processFrame(image: ImageProxy) {
        val plane = image.planes[0]
        val buf = plane.buffer; val rs = plane.rowStride; val ps = plane.pixelStride
        val w = image.width; val h = image.height
        val rw = (w*0.4f).toInt(); val rh = (h*0.4f).toInt()
        val x0 = (w-rw)/2; val y0 = (h-rh)/2
        var sum = 0L; var cnt = 0
        for (row in y0 until y0+rh step 2) for (col in x0 until x0+rw step 2) {
            val idx = row*rs+col*ps
            if (idx < buf.capacity()) { sum += (buf.get(idx).toInt() and 0xFF); cnt++ }
        }
        if (cnt == 0) return
        processor.addSample(sum.toDouble()/cnt, System.currentTimeMillis())
        if (System.currentTimeMillis() - measureStartMs >= MEASURE_DURATION_MS)
            handler.post { showFinalResult(); stopMeasurement() }
    }

    private fun updateUI() {
        val elapsed = System.currentTimeMillis() - measureStartMs
        val pct = min(100.0, elapsed.toDouble() / MEASURE_DURATION_MS * 100.0).toInt()
        b.progressBar.progress = pct
        val remaining = ((MEASURE_DURATION_MS - elapsed)/1000).coerceAtLeast(0)
        val rrCount = processor.rrIntervals.size
        when {
            elapsed < 5000 -> { b.statusText.text="Калибровка..."; b.tvProgress.text="Калибровка сигнала..."; setStep(2) }
            rrCount < 3    -> { b.statusText.text="Поиск пульса"; b.tvProgress.text="Держите палец неподвижно" }
            else           -> { b.statusText.text="Измерение"; b.tvProgress.text="Осталось ${remaining} сек • ${rrCount} ударов"; setStep(3) }
        }
        val q = processor.quality
        b.tvQuality.text = when { q>0.5f->"● Хороший"; q>0.2f->"● Слабый"; else->"● Нет сигнала" }
        b.tvQuality.setTextColor(when { q>0.5f->0xFF00E87A.toInt(); q>0.2f->0xFFFFB020.toInt(); else->0xFFFF4466.toInt() })

        b.waveformView.update(processor.filteredBuffer.toList(), processor.peakMarkers.toList(), q)

        val m = processor.calculateHRV() ?: return
        b.tvBpm.text = m.bpm.toString()
        b.tvBpm.setTextColor(if (m.bpm > 100) 0xFFFF4466.toInt() else 0xFFE8F4FF.toInt())

        fun set(card: MetricCard, text: String, pct: Int) {
            card.value.text = text; card.bar.progress = pct.coerceIn(0,100)
        }
        set(mRmssd, "${m.rmssd.roundToInt()} мс", (m.rmssd/80*100).toInt())
        set(mSdnn,  "${m.sdnn.roundToInt()} мс",  (m.sdnn/100*100).toInt())
        set(mPnn50, "${"%.1f".format(m.pnn50)} %", (m.pnn50/50*100).toInt())
        set(mStress,"${m.stressIndex.roundToInt()}", (m.stressIndex/400*100).toInt())
        set(mRr,    "${m.meanRR.roundToInt()} мс", ((m.meanRR-300)/900*100).toInt())

        val stressColor = when { m.stressIndex<100->0xFF00E87A.toInt(); m.stressIndex<250->0xFFFFB020.toInt(); else->0xFFFF4466.toInt() }
        mStress.value.setTextColor(stressColor)
        mStress.bar.progressTintList = android.content.res.ColorStateList.valueOf(stressColor)
    }

    private fun showFinalResult() {
        val m = processor.calculateHRV()
        val msg = if (m != null) "Готово! Пульс: ${m.bpm} уд/мин, RMSSD: ${m.rmssd.roundToInt()} мс" else "Измерение завершено"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); setStep(4)
    }

    private fun animateHeart() {
        val sx = ObjectAnimator.ofFloat(b.ivHeart,"scaleX",1f,1.4f,1f)
        val sy = ObjectAnimator.ofFloat(b.ivHeart,"scaleY",1f,1.4f,1f)
        AnimatorSet().apply { playTogether(sx,sy); duration=280; start() }
    }

    private fun setStep(n: Int) {
        listOf(b.step1,b.step2,b.step3,b.step4).forEachIndexed { i,v -> v.alpha = if (i<n) 1f else 0.35f }
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
