package com.cardiohrv.monitor

import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

data class HrvMetrics(
    val bpm: Int, val rmssd: Double, val sdnn: Double,
    val pnn50: Double, val stressIndex: Double, val meanRR: Double, val rrCount: Int
)

class SignalProcessor {
    private var emaSlowVal: Double? = null
    private var emaFastVal: Double = 0.0
    private val ALPHA_SLOW = 0.04
    private val ALPHA_FAST = 0.45
    private val MAX_BUFFER = 360

    val filteredBuffer = ArrayDeque<Double>()
    private val peakWindow = ArrayDeque<Double>()
    private var lastPeakTimeMs: Long = 0L
    private val MIN_PEAK_DIST_MS = 333L

    val rrIntervals = ArrayDeque<Double>()
    val peakMarkers = ArrayDeque<Int>()

    var quality: Float = 0f; private set
    var onBeat: (() -> Unit)? = null

    fun reset() {
        emaSlowVal = null; emaFastVal = 0.0
        filteredBuffer.clear(); peakWindow.clear()
        lastPeakTimeMs = 0L; rrIntervals.clear(); peakMarkers.clear(); quality = 0f
    }

    fun addSample(greenMean: Double, timestampMs: Long): Double {
        val slow = emaSlowVal?.let { ALPHA_SLOW * greenMean + (1 - ALPHA_SLOW) * it } ?: greenMean
        emaSlowVal = slow
        val filtered = ALPHA_FAST * (greenMean - slow) + (1 - ALPHA_FAST) * emaFastVal
        emaFastVal = filtered
        filteredBuffer.addLast(filtered)
        if (filteredBuffer.size > MAX_BUFFER) filteredBuffer.removeFirst()
        peakWindow.addLast(filtered)
        if (peakWindow.size > 90) peakWindow.removeFirst()
        updateQuality()
        if (peakWindow.size >= 30 && quality > 0.1f) detectPeak(filtered, timestampMs)
        return filtered
    }

    private fun updateQuality() {
        val recent = filteredBuffer.takeLast(30.coerceAtMost(filteredBuffer.size))
        if (recent.isEmpty()) { quality = 0f; return }
        val mean = recent.average()
        val std = sqrt(recent.map { (it - mean) * (it - mean) }.average())
        quality = min(1.0, std / 1.5).toFloat()
    }

    private fun detectPeak(value: Double, nowMs: Long) {
        val maxV = peakWindow.max(); val minV = peakWindow.min()
        val range = maxV - minV; if (range < 0.01) return
        if (value <= minV + range * 0.62) return
        if (nowMs - lastPeakTimeMs < MIN_PEAK_DIST_MS) return
        val tail = filteredBuffer.takeLast(6)
        if (value < tail.max()) return
        val timeSinceLast = nowMs - lastPeakTimeMs
        if (lastPeakTimeMs > 0 && timeSinceLast in 300..2000) {
            rrIntervals.addLast(timeSinceLast.toDouble())
            if (rrIntervals.size > 120) rrIntervals.removeFirst()
            onBeat?.invoke()
        }
        lastPeakTimeMs = nowMs
        peakMarkers.addLast(filteredBuffer.size - 1)
        if (peakMarkers.size > 20) peakMarkers.removeFirst()
    }

    fun calculateHRV(): HrvMetrics? {
        val rr = rrIntervals.toList(); if (rr.size < 4) return null
        val meanRR = rr.average()
        val bpm = (60000.0 / meanRR).toInt().coerceIn(30, 220)
        val sdnn = sqrt(rr.map { (it - meanRR) * (it - meanRR) }.average())
        val diffs = rr.zipWithNext { a, b -> b - a }
        val rmssd = if (diffs.isEmpty()) 0.0 else sqrt(diffs.map { it * it }.average())
        val pnn50 = if (diffs.isEmpty()) 0.0 else diffs.count { abs(it) > 50 }.toDouble() / diffs.size * 100.0
        val bins = 50; val minRR = rr.min(); val maxRR = rr.max()
        val binSize = ((maxRR - minRR) / bins).coerceAtLeast(1.0)
        val hist = IntArray(bins)
        rr.forEach { v -> hist[min(bins-1, ((v - minRR) / binSize).toInt())]++ }
        val maxBin = hist.max(); val modeIdx = hist.indexOfFirst { it == maxBin }
        val Mo = minRR + (modeIdx + 0.5) * binSize
        val AMo = maxBin.toDouble() / rr.size * 100.0
        val MxDMn = maxRR - minRR
        val stressIndex = if (MxDMn > 0) AMo / (2 * MxDMn * Mo) * 1000.0 else 0.0
        return HrvMetrics(bpm, rmssd, sdnn, pnn50, stressIndex, meanRR, rr.size)
    }
}
