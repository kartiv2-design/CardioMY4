package com.cardiohrv.monitor

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val DISPLAY = 300
    private val paintGrid   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(20,0,220,120); strokeWidth=1f; style=Paint.Style.STROKE }
    private val paintLine   = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth=3f; style=Paint.Style.STROKE; strokeJoin=Paint.Join.ROUND; strokeCap=Paint.Cap.ROUND }
    private val paintFill   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.FILL }
    private val paintPeak   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.argb(230,0,232,122); style=Paint.Style.FILL }
    private val paintCursor = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.argb(100,0,200,255); strokeWidth=2f; style=Paint.Style.STROKE; pathEffect=DashPathEffect(floatArrayOf(8f,8f),0f) }

    private var buffer: List<Double> = emptyList()
    private var peakMarkers: List<Int> = emptyList()
    var quality: Float = 0f

    private val linePath = Path()
    private val fillPath = Path()

    fun update(buffer: List<Double>, peaks: List<Int>, quality: Float) {
        this.buffer = buffer; this.peakMarkers = peaks; this.quality = quality; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return

        for (i in 0..10) canvas.drawLine(i*w/10,0f,i*w/10,h,paintGrid)
        for (i in 0..4)  canvas.drawLine(0f,i*h/4,w,i*h/4,paintGrid)

        val buf = buffer; if (buf.size < 2) return
        val maxV = buf.max(); val minV = buf.min(); val range = (maxV-minV).coerceAtLeast(0.001)
        fun norm(v: Double) = ((v - minV) / range).toFloat()

        val n = buf.size; val off = (DISPLAY - n).coerceAtLeast(0); val step = w / (DISPLAY - 1)
        val signalColor = if (quality > 0.3f) Color.argb(210,0,232,122) else Color.argb(200,255,176,32)
        paintLine.color = signalColor
        paintFill.color = if (quality > 0.3f) Color.argb(15,0,232,122) else Color.argb(8,255,176,32)

        linePath.reset(); fillPath.reset()
        val fx = off * step; val fy = h - norm(buf[0])*h*0.82f - h*0.09f
        linePath.moveTo(fx,fy); fillPath.moveTo(fx,h); fillPath.lineTo(fx,fy)
        for (i in 1 until n) {
            val x=(off+i)*step; val y=h-norm(buf[i])*h*0.82f-h*0.09f
            linePath.lineTo(x,y); fillPath.lineTo(x,y)
        }
        val lx = (off+n-1)*step; fillPath.lineTo(lx,h); fillPath.close()
        canvas.drawPath(fillPath,paintFill); canvas.drawPath(linePath,paintLine)

        for (pidx in peakMarkers) {
            val i = pidx-(DISPLAY-n); if (i<0||i>=n) continue
            val x=(off+i)*step; val y=h-norm(buf[i])*h*0.82f-h*0.09f
            canvas.drawCircle(x,y,6f,paintPeak)
        }
        canvas.drawLine(lx,0f,lx,h,paintCursor)
    }
}
